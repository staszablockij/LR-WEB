package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam; // Додайте імпорт для RequestParam
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/hello")
    public String getFoos(@RequestParam(defaultValue = "user") String name) {
        return "hello " + name;
    }
}
